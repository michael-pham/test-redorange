<?php

namespace Api\ModelNames\Controllers;

use Illuminate\Http\Request;
use Infrastructure\Http\Controller;
use Api\ModelNames\Requests\CreateModelNameRequest;
use Api\ModelNames\Services\ModelNameService;

class ModelNameController extends Controller
{
  private $modelNameService;

  public function __construct(ModelNameService $modelNameService)
  {
    $this->modelNameService = $modelNameService;
  }

  public function getAll()
  {
    $resourceOptions = $this->parseResourceOptions();

    $data = $this->modelNameService->getAll($resourceOptions);
    $parsedData = $this->parseData($data, $resourceOptions, 'modelNames');

    return $this->response($parsedData);
  }

  public function getById($modelNameId)
  {
    $resourceOptions = $this->parseResourceOptions();

    $data = $this->modelNameService->getById($modelNameId, $resourceOptions);
    $parsedData = $this->parseData($data, $resourceOptions, 'modelName');

    return $this->response($parsedData);
  }

  public function create(CreateModelNameRequest $request)
  {
    $data = $request->get('modelName', []);

    return $this->response($this->modelNameService->create($data), 201);
  }

  public function update($modelNameId, Request $request)
  {
    $data = $request->get('modelName', []);

    return $this->response($this->modelNameService->update($modelNameId, $data));
  }

  public function delete($modelNameId)
  {
    return $this->response($this->modelNameService->delete($modelNameId));
  }
}
